import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Scanner;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import com.fazecast.jSerialComm.*;

public class Test {
	
	boolean rotate = false;                                                 // tells the program if the user would like to rotate through indications
	boolean portOpen = false;                                               // used to tell the program if the port has been successfully opened
	boolean aspectVisible = false;                                          // used to tell the program if the aspect list is visible to the end user
	boolean durVisible = false;                                             // used to tell the program if the duration text field is visible to the end user
	boolean debugGUI = false;                                               // used to tell the program that the programmer is only interested in debugging the GUI

	String indicationNum = "";                                              // used to store the indication number if the program is rotating through indications

	InputStream in = null;                                                  // used to receive serial input from the Arduino
	OutputStream out = null;                                                // used to send serial data to the Arduino

	/**
	 * Looks for the serial port the Arduino is connected to
	 * 
	 * @param comPortIn - the variable that will store the serial port
	 * @return comPortIn - the serial port the Arduino is connected to
	 */
	SerialPort findP(SerialPort comPortIn) {
		try {                                                 // tries to find the port that the Arduino is on
			comPortIn = SerialPort.getCommPorts()[0];         // finds the port the Arduino is connected to
			portOpen = true;                                  // if successful, the program will be told that the port is found
		} catch (IndexOutOfBoundsException e) {               // if the port fails to be found, print out a message stating so
			System.out.println("Port has failed to open");    // print message to the Java Console
			JFrame frame = new JFrame();                      // creates a frame for the dialog box
			Object[] options = {"Retry", "Cancel"};           // creates the buttons for the dialog box
			int n = JOptionPane.showOptionDialog(frame,       // creates the dialog box itself and sets the result to an integer
					"Port failed to open. Check to make sure that the Arduino is plugged in and nothing else is using it.",
					"Port Error",
					JOptionPane.YES_NO_OPTION,
					JOptionPane.WARNING_MESSAGE,
					null,
					options,
					options[1]);
			if (n == JOptionPane.YES_OPTION) {                // if the "Retry" button was clicked on
				try {
					comPortIn = SerialPort.getCommPorts()[0]; // re-attempt to find the port 
					portOpen = true;
				} catch (ArrayIndexOutOfBoundsException ee) { // if the port fails to open, the program will hang in the next while (true) block until the port is opened
					System.out.println("Port is still failing to open");
				}
			} else if (n == JOptionPane.NO_OPTION || n == JOptionPane.CLOSED_OPTION) { // if the "Cancel" button or the red 'X' was clicked on
				JFrame frame2 = new JFrame();
				Object[] options2 = {"Yes", "No"};				// sets up a dialog box asking the programmer if they're debugging the GUI
				int o = JOptionPane.showOptionDialog(frame2,
						"Test GUI?",
						"Debug GUI?",
						JOptionPane.YES_NO_OPTION,
						JOptionPane.QUESTION_MESSAGE,
						null,
						options2,
						options2[1]);
				if (o == JOptionPane.YES_OPTION) {				// if so, enable GUI debugging
					debugGUI = true;
					System.out.println("GUI debug mode enabled. No data will be sent.");
				} else if (o == JOptionPane.NO_OPTION) {		// if not, terminate the program
					System.out.println("User exited program due to Port Error.");
					System.exit(0);
				}
			}
		}

		while (true) {                                        // This block will hang the program in order to re-attempt to find the port the Arduino is connected to
			if (portOpen || debugGUI) {                       // If the port is successfully opened from the first/second attempt, or if debug mode is enabled:
				break;                             	          // Get out of this while loop 
			}
			while (!portOpen) {                               // While the port fails to be found:
				JFrame frame = new JFrame();				  // Keep showing the dialog box until either the port is found, or the cancel/red 'X' button is pressed
				Object[] options = {"Retry", "Cancel"};
				int n = JOptionPane.showOptionDialog(frame,
						"Port failed to open. Check to make sure that the Arduino is plugged in and nothing else is using it.",
						"Port Error",
						JOptionPane.YES_NO_OPTION,
						JOptionPane.WARNING_MESSAGE,
						null,
						options,
						options[1]);
				if (n == JOptionPane.YES_OPTION) {
					try {
						comPortIn = SerialPort.getCommPorts()[0];
						portOpen = true;
					} catch (ArrayIndexOutOfBoundsException e) {
						System.out.println("Port is still failing to open");
					}
				} else if (n == JOptionPane.NO_OPTION || n == JOptionPane.CLOSED_OPTION) {
					System.out.println("User exited program due to Port Error");
					System.exit(0);
				}
				System.out.flush();                    // Flushes the serial input to keep the communication up with the Arduino so that the program doesn't hang prematurely
			}
			System.out.flush();
			break;                                     // Exits this block if the port is found
		}
		return comPortIn;                              // returns the port that the Arduino is connected to
	}
	
	/**
	 * Finds the header from the serial input
	 * 
	 * @param comPortIn - the serial port the Arduino is connected to
	 */
	void findHeader(SerialPort comPortIn) {
		if (!debugGUI) {
			comPortIn.openPort();                                                      // opens the port to communication
			comPortIn.setComPortTimeouts(SerialPort.TIMEOUT_READ_SEMI_BLOCKING, 0, 0); // avoids glitch in Windows
			in = comPortIn.getInputStream();                                      // initializes the input stream from the Arduino
			out = comPortIn.getOutputStream();                                    // initializes the output stream to the Arduino
			char header[] = new char[16];                                            // used to store the header of the program to verify the starting point
			char clipped[] = new char[15];                                           // used to compare the header

			/**
			 * This section will advance the buffer to the proper starting point of the program by looking for the "SignalController" text
			 * The Arduino sometimes lags to where the text input seems scrambled sometimes. This will flush the input until it's caught up
			 */
			for (int j = 0; j < 16; j++) {                             // reads in the first 16 characters sent in from the Arduino
				try {
					char a = (char) in.read();
					header[j] = a;
				} catch (NullPointerException e) {                     // if another instance of this program is running, or if another program is using the serial port, display error message
					JFrame frame = new JFrame();
					JOptionPane.showMessageDialog(frame, "Error: NullPointerException. This can be caused by multiple instances running\n"
							+ "or another program using the Arduino. Make sure all instances of the SignalController are closed\n"
							+ "and ensure that no other programs are using the Arduino, then try again.", "Serial Error", JOptionPane.ERROR_MESSAGE);
					System.out.println("Serial Error: Duplicate Instance. The program has been terminated.");
					System.exit(0);
				} catch (IOException ee) { }
			}
			while (!(new String(header)).equals("SignalController")) {  // while the program hasn't found "SignalController" (if the Arduino hasn't sent "SignalController" yet)
				char a = 0;
				try { a = (char) in.read(); } catch (IOException e) { } // read in the next character from the Arduino
				for (int i = 0; i < 15; i++) {                          // delete the first character from the header array and shift the rest over
					clipped[i] = header[i + 1];
					header[i] = clipped[i];
				}
				header[15] = a;                                         // add the next character to the end of the header
			}
			System.out.print(header);                                   // print out the header once "SignalController" has been found
		}
	}

	/**
	 * Sends data to the Arduino
	 * 
	 * @param send - String to send to the Arduino
	 * @throws IOException if an I/O error occurs
	 */
	void sendArduino(String send) throws IOException {
		if (!debugGUI) {                     // if debug GUI mode isn't enabled:
			System.out.println(send);        // print out what is being sent to the Arduino on the Java Console
			byte inByte[] = send.getBytes(); // translate the String being sent into bytes
			out.write(inByte);               // send out the String
		}
	}

	/**
	 * Reads in serial input from Arduino
	 * 
	 * @throws IOException if an I/O error occurs
	 */
	void readArduino() throws IOException {
		//		char[] fiveIn = new char[5];
		//		int i = 0;
		char oneIn = 0;                       // stores one character at a time from the serial input
		while ((int) oneIn != 6) {            // prints the serial output until it hits the ASCII Acknowledge code (used to denote end of output)
			oneIn = (char) in.read();         // reads in a character from the Arduino
			//			fiveIn[i++ % 5] = oneIn;
			//			System.out.println(" " + new String(fiveIn));
			//			if (new String(fiveIn).equals("ERROR")) {
			//				System.out.println("*NE*");
			//			}
			if ((int) oneIn != 6) {           // if the read in character doesn't equal the terminate character:
				System.out.print(oneIn);      // print out one character at a time received from the Arduino
			}
			if (rotate && (int) oneIn != 6) { // if the program is rotating through indications:
				indicationNum += oneIn;       // store the number
			}
		}
	}

	public static void main(String[] args) throws IOException {
		Test ctrl = new Test();                                      // creates instance of this program
		SerialPort comPort = null;                                               // used to retrieve the serial port the Arduino is hooked up to
		comPort = ctrl.findP(comPort);                                           // finds the serial port the Arduino is connected to
		ctrl.findHeader(comPort);												 // finds the "SignalController" text from the serial input		
		ctrl.readArduino();
		Scanner in = new Scanner(System.in);
		String a = in.nextLine();
		ctrl.sendArduino(a);
		ctrl.readArduino();
	}
	
}
